package com.lumen.LambdaDemo;

public interface Shaper {
	double CalcArea(double x,double y);

}
