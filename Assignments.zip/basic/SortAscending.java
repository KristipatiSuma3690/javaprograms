package com.lumen.basic;

import java.util.Arrays;

public class SortAscending {

	public static void main(String[] args) {
		int [] Array= {30,20,10,50};
		Arrays.sort(Array);
		for(int i:Array) {
			System.out.println(i);
		}
	}

}
