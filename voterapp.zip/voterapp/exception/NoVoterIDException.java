package com.voterapp.exception;

public class NoVoterIDException extends Exception {

	public NoVoterIDException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoVoterIDException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
