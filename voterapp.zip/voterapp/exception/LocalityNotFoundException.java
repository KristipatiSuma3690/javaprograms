package com.voterapp.exception;

public class LocalityNotFoundException extends Exception {

	public LocalityNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LocalityNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
