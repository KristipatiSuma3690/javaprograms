package com.voterapp.exception;

public class InValidVoterException extends Exception {

	public InValidVoterException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InValidVoterException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
