package com.userapp.exception;

public class TooLongException extends Exception {

	public TooLongException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TooLongException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
