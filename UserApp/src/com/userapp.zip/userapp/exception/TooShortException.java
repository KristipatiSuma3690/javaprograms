package com.userapp.exception;

public class TooShortException extends Exception {

	public TooShortException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TooShortException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
