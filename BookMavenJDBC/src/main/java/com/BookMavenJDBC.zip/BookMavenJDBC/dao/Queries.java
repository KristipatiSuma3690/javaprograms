package com.lumen.dao;

public class Queries {
	public static final String createquery="create table Book(title varchar(200),author varchar(100)"
			+ "category varchar(100), bookid int primary key, price float)";
	public static final String insertQuery="insert into Book values(?,?,?,?,?)";
	public static final String updateQuery="update Book set price=? where bookid=?";
	public static final String deleteQuery="delete from Book where bookid=?";
	public static final String querybyid="select * from Book where bookid=?";
	public static final String querybyauthor="select * from Book where author=?";
	public static final String querybycategory="select * from Book where category=?";
	public static final String querybyprice="select * from Book where price=?";
	public static final String querybyauthorandcategory="select * from Book where author=? and category=? ";
	

}
